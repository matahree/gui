
public abstract class GeometricPrimitive {
	
	public abstract double  perimater();
	public abstract double  area();
	
}
